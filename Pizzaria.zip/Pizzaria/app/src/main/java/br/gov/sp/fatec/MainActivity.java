package br.gov.sp.fatec;

import static android.app.PendingIntent.getActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btnCalcular;
    EditText edtPizza1, edtPizza2, edtPizza3, edtPizza4;



    double soma = 0;

    String texto = "";

    TextView resultado;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnCalcular = findViewById(R.id.btnCalcular);
        edtPizza1 = findViewById(R.id.edtPizza1);
        edtPizza2 = findViewById(R.id.edtPizza2);
        edtPizza3 = findViewById(R.id.edtPizza3);
        edtPizza4 = findViewById(R.id.edtPizza4);
        resultado = findViewById(R.id.resultado);

    }

    public void calcular(View view){
        somar();
    }

    public void pedidoFeito(View view){
        somar();

        if(soma != 0){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Pedido realizado com sucesso!");
        builder.setMessage(String.format("valor: R$ %.2f", soma));

        builder.create().show();
        }else if(soma == 0){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setTitle("Nenhum item relacionado ao pedido");
            builder.setMessage("pedido não realizado");

            builder.create().show();
        }
        texto = "";
    }

    public void somar(){
        soma = 0;

        if(!TextUtils.isEmpty(edtPizza1.getText())){
            soma += 42*(Double.valueOf(String.valueOf(edtPizza1.getText())));
        }
        if(!TextUtils.isEmpty(edtPizza2.getText())){
            soma += 45*(Double.valueOf(String.valueOf(edtPizza2.getText())));
        }
        if(!TextUtils.isEmpty(edtPizza3.getText())){
            soma += 45*(Double.valueOf(String.valueOf(edtPizza3.getText())));
        }
        if(!TextUtils.isEmpty(edtPizza4.getText())){
            soma += 56*(Double.valueOf(String.valueOf(edtPizza4.getText())));
        }
        resultado.setText(String.format("R$ %.2f", soma));
        texto = String.valueOf(soma);}

}