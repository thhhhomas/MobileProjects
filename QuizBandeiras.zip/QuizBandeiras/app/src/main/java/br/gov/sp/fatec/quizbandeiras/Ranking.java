package br.gov.sp.fatec.quizbandeiras;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Ranking extends AppCompatActivity {

    Intent it;
    public TextView txtNome, txtPontos;

    Global g = new Global();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ranking);



        txtNome = findViewById(R.id.txtNome);
        txtPontos = findViewById(R.id.txtPontos);

        txtNome.setText(g.getNome());
        txtPontos.setText(String.valueOf(g.getPontos()));



    }

    public void home(View view){
        //it = new Intent(this, MainActivity.class);
        this.finish();
        //startActivity(it);
    }

    public void restart(View view){
        g.setPontos(0);
        it = new Intent(this, TelaQuiz.class);
        this.finish();
        startActivity(it);
    }
}