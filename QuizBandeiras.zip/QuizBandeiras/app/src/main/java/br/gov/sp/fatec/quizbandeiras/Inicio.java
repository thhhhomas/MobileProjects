package br.gov.sp.fatec.quizbandeiras;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Inicio extends AppCompatActivity {

    private Button btnIniciar, btnSair;
    private EditText edtNome;

    Intent it;

    Global g = new Global();

    private MediaPlayer mediaPlayer = new MediaPlayer();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //ActionBar bar = getSupportActionBar();
        //bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#512817")));

        btnIniciar = findViewById(R.id.btnIniciar);
        btnSair = findViewById(R.id.btnSair);
        edtNome = findViewById(R.id.edtNome);

        mediaPlayer = MediaPlayer.create(this, R.raw.foto);



        edtNome.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.toString().trim().length() != 0){
                    btnIniciar.setEnabled(true);
                    g.setNome(edtNome.getText().toString());
                }
                else{
                    btnIniciar.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        mediaPlayer.stop();
        super.onBackPressed();
    }

    public void sair(View view){

        if(mediaPlayer.isPlaying()){
            mediaPlayer.stop();
        }
        this.finish();
    }

    public void iniciar(View view){
        if(mediaPlayer.isPlaying()){
            mediaPlayer.pause();
        }
        g.setPontos(0);
        it = new Intent(this, TelaQuiz.class);
        startActivity(it);
    }

    public void foto(View view){
        if(!mediaPlayer.isPlaying()){
            mediaPlayer.reset();
            mediaPlayer = MediaPlayer.create(this, R.raw.foto);
            mediaPlayer.start();
        }
    }
}