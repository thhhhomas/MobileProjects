package br.gov.sp.fatec.quizbandeiras;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Random;

public class TelaQuiz2 extends AppCompatActivity {

    private RadioButton[] rdbs = new RadioButton[4];
    private RadioButton rdbSecreto;
    ImageView imgBandeira;
    private Button btnResponder;

    int pontos = 0, respCerta;

    Intent it;
    String[] paises = {"Brasil", "Marrocos", "Ilha de Man", "Indonésia", "Papua-Nova Guiné", "Républica Democrática do Congo",
            "República do Congo", "Nicarágua", "Sri Lanka", "Vanuatu", "Estados Unidos", "Coréia do Norte", "Suriname",
            "Romênia", "Chade", "Burkina Faso", "Madagascar", "Nova Zelândia", "Estônia", "Lituânia", "Moçambique", "Moldávia", "Belize"};

    int indicePais = 1;
    Random r = new Random();

    private MediaPlayer mediaPlayer = new MediaPlayer();
    private MediaPlayer mediaPlayerErro = new MediaPlayer();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_quiz);

        rdbs[0] = findViewById(R.id.rdbUm);
        rdbs[1] = findViewById(R.id.rdbDois);
        rdbs[2] = findViewById(R.id.rdbTres);
        rdbs[3] = findViewById(R.id.rdbQuatro);
        rdbSecreto = findViewById(R.id.edbSecreto);
        btnResponder = findViewById(R.id.btnResponder);
        imgBandeira = findViewById(R.id.imgBandeira);
        btnResponder.setEnabled(false);
        rdbs[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnResponder.setEnabled(true);
            }
        });
        rdbs[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnResponder.setEnabled(true);
            }
        });
        rdbs[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnResponder.setEnabled(true);
            }
        });
        rdbs[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnResponder.setEnabled(true);
            }
        });
        mediaPlayer = MediaPlayer.create(this, R.raw.feliz);
        mediaPlayerErro = MediaPlayer.create(this, R.raw.errou);

        switch (indicePais) {
            case 0:
                imgBandeira.setImageResource(R.drawable.brasil);
                break;
            case 1:
                imgBandeira.setImageResource(R.drawable.marrocos);
                break;
            case 2:
                imgBandeira.setImageResource(R.drawable.ilhademan);
                break;
            case 3:
                imgBandeira.setImageResource(R.drawable.indonesia);
                break;
            case 4:
                imgBandeira.setImageResource(R.drawable.papua);
                break;
            case 5:
                imgBandeira.setImageResource(R.drawable.republicademocraticadocongo);
                break;
            case 6:
                imgBandeira.setImageResource(R.drawable.republicadocongo);
                break;
            case 7:
                imgBandeira.setImageResource(R.drawable.nicaragua);
                break;
            case 8:
                imgBandeira.setImageResource(R.drawable.srilanka);
                break;
            case 9:
                imgBandeira.setImageResource(R.drawable.vanuatu);
                break;
        }

        proximaBandeira();
    }

    public void proximaBandeira(){
        if(indicePais < 10) {
            ArrayList listaPaises = new ArrayList<String>();
            int auxRandom = r.nextInt(4);
            respCerta = auxRandom;
            rdbs[auxRandom].setText(paises[indicePais]);
            listaPaises.add(paises[indicePais]);

            for (int i = 0; i < 4; i++) {
                if (respCerta != i) {
                    auxRandom = r.nextInt(paises.length);
                    if (!listaPaises.contains(paises[auxRandom])) {
                        rdbs[i].setText(paises[auxRandom]);
                        listaPaises.add(paises[auxRandom]);
                    } else {
                        i--;
                    }
                }
            }
        }
    }

    public void responder(View view){
        if(rdbs[0].isChecked() || rdbs[1].isChecked() || rdbs[2].isChecked() || rdbs[3].isChecked()) {
            if (rdbs[respCerta].isChecked()) {
                Global g = new Global();
                pontos += g.getPontos();
                pontos++;
                g.setPontos(pontos);
                if(!mediaPlayer.isPlaying()){
                    mediaPlayer.start();
                }
            }
            else{
                if(!mediaPlayerErro.isPlaying()){
                    mediaPlayerErro.start();
                }
            }
            rdbSecreto.setChecked(true);
            it = new Intent(this, TelaQuiz3.class);
            this.finish();
            startActivity(it);

        }
    }
}