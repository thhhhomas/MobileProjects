package br.gov.sp.fatec.conta;

import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private TextView txtTaxa, txtContaTotal, txtValorPessoa;
    private EditText edtConsumoTotal, edtCouvert, edtPessoas;
    private Button btnCalcular;

    private double taxa = 0, total = 0, porPessoa = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        txtTaxa = findViewById(R.id.txtTaxa);
        txtContaTotal = findViewById(R.id.txtContaTotal);
        txtValorPessoa = findViewById(R.id.txtValorPessoa);

        edtConsumoTotal = findViewById(R.id.edtConsumoTotal);
        edtCouvert = findViewById(R.id.edtCouvert);
        edtPessoas = findViewById(R.id.edtPessoas);

        btnCalcular = findViewById(R.id.btnCalcular);
    }

    public void calcular(View view){
        if(!edtCouvert.getText().toString().isEmpty() && !edtPessoas.getText().toString().isEmpty() && !edtConsumoTotal.getText().toString().isEmpty()){
            taxa = Double.valueOf(String.valueOf(edtConsumoTotal.getText()))*(0.1);

            txtTaxa.setText(String.format("%.2f", taxa));

            total = taxa+(Double.valueOf(String.valueOf(edtConsumoTotal.getText())))+(Double.valueOf(String.valueOf(edtCouvert.getText())));

            txtContaTotal.setText(String.format("%.2f", total));

            porPessoa = total / (Integer.parseInt(String.valueOf(edtPessoas.getText())));

            txtValorPessoa.setText(String.format("%.2f", porPessoa));
        }
        else{
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("todos os campos precisam ser preenchidos");
            builder.setTitle("Campos vazios");
            builder.setPositiveButton("Ok", null);
            builder.create().show();
        }
    }
}