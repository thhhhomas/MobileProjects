package br.gov.sp.fatec.quizbandeiras;
public class Global{
    private static String nome;
    private static int pontos;
    void setNome(String s){
        nome = s;
    }
    String getNome(){return nome;}
    void setPontos(int i){
        pontos = i;
    }
    int getPontos(){
        if(pontos >= 0) return pontos;
        else return 0;
    }
}